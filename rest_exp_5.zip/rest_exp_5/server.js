// server.js
// Demonstration of Express middleware for logging and JSON parsing

const express = require('express');
const morgan = require('morgan'); // middleware for logging
const app = express();

// ------------------- MIDDLEWARE SETUP -------------------

// 1️⃣ Morgan logs each incoming request (method, URL, response time, status)
app.use(morgan('dev'));

// 2️⃣ express.json() parses incoming JSON requests automatically
app.use(express.json());

// ------------------- SAMPLE ROUTES -------------------

// GET route
app.get('/', (req, res) => {
  res.status(200).send('Welcome to Middleware Demo 🚀');
});

// POST route to demonstrate JSON parsing
app.post('/user', (req, res) => {
  const userData = req.body;
  console.log('Received user data:', userData);

  res.status(201).json({
    message: 'User data received successfully ✅',
    data: userData
  });
});

// ------------------- START SERVER -------------------
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
